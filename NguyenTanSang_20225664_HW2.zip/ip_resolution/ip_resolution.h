#ifndef IP_RESOLUTION_H
#define IP_RESOLUTION_H

void resolveIP(const char *ip);

#endif
