#ifndef DNS_RESOLUTION_H
#define DNS_RESOLUTION_H

void resolveDomain(const char *domain);

#endif
